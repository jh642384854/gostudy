package main

import (
	"github.com/kataras/iris"
)

func main() {
	app := iris.New()
	app.Get("/", func(ctx iris.Context) {

	})
	app.Run(iris.Addr(":8080"))
	app.PartyFunc("/cpanel", func(child iris.Party) {
		child.Get("/", func(ctx iris.Context) {

		})
	})
	cpanel := app.Party("/cpanel")
	cpanel.Get("/", func(ctx iris.Context) {

	})
}
