package main

import (
	"github.com/kataras/iris"
)

func main() {
	app := iris.New()

	/*
	users := app.Party("/users",myAuthMiddlewareHandler)
	users.Get("/{id:int}/profile",userProfileHandler)
	users.Get("/inbox/{id:int}",userMessageHandler)
	*/

	app.PartyFunc("/users", func(users iris.Party) {
		users.Use(myAuthMiddlewareHandler)
		users.Get("/{id:int}/profile",userProfileHandler)
		users.Get("/inbox/{id:int}",userMessageHandler)
	})

	app.Run(iris.Addr(":8080"))
}

func myAuthMiddlewareHandler(ctx iris.Context)  {
	ctx.WriteString("Authentication failed")
	ctx.Next()
}

func userProfileHandler(ctx iris.Context){
	id := ctx.Params().Get("id")
	ctx.WriteString(id)
}

func userMessageHandler(ctx iris.Context){
	id := ctx.Params().Get("id")
	ctx.WriteString(id)
}

//各个请求方法测试的处理器
func handler(ctx iris.Context){
	ctx.Writef("Hello from method:%s and path:%s",ctx.Method(),ctx.Path())
}
//基本路由测试一
func Demo1()  {
	app := iris.New()
	app.Handle("GET","/", func(ctx iris.Context) {
		ctx.HTML("<h1>Hello iris </h1>")
	})
	app.Run(iris.Addr(":8080"))
}
/**
	为了使最终开发人员更容易，iris为所有HTTP方法提供了功能。第一个参数是路由的请求路径，
	第二个可变参数应该包含一个或多个iris.Handler，当用户从服务器请求该特定的资源路径时，由注册顺序执行。
 */
func Demo2()  {
	app := iris.New()
	//GET 方法
	app.Get("/", handler)
	// POST 方法
	app.Post("/", handler)
	// PUT 方法
	app.Put("/", handler)
	// DELETE 方法
	app.Delete("/", handler)
	//OPTIONS 方法
	app.Options("/", handler)
	//TRACE 方法
	app.Trace("/", handler)
	//CONNECT 方法
	app.Connect("/", handler)
	//HEAD 方法
	app.Head("/", handler)
	// PATCH 方法
	app.Patch("/", handler)
	//任意的http请求方法如option等
	app.Any("/", handler)
	app.Run(iris.Addr(":8080"))
}

/**
路由分组
分组路由 由路径前缀分组的一组路由可以（可选）共享相同的中间件处理程序和模板布局。一个组也可以有一个嵌套组。
.Party 正在用于分组路由，开发人员可以声明无限数量的（嵌套）组。也可以使用接受子路由器（Party）的功能编写相同的内容。
 */
func Demo3(){
	app := iris.New()

	/*
	users := app.Party("/users",myAuthMiddlewareHandler)
	users.Get("/{id:int}/profile",userProfileHandler)
	users.Get("/inbox/{id:int}",userMessageHandler)
	*/
	//下面这种写法和上面的效果是一样的。
	app.PartyFunc("/users", func(users iris.Party) {
		users.Use(myAuthMiddlewareHandler)
		users.Get("/{id:int}/profile",userProfileHandler)
		users.Get("/inbox/{id:int}",userMessageHandler)
	})

	app.Run(iris.Addr(":8080"))
}