package main

import (
	"github.com/kataras/iris"
	"github.com/kataras/iris/mvc"
)

type MyController struct {

}

func main() {
	app := iris.New()

	mvc.Configure(app.Party("/root"),myMVC)

	app.Run(iris.Addr(":8080"))
}

func myMVC(app *mvc.Application){
	app.Handle(new(MyController))
}

func (m *MyController) BeforeActivation(b mvc.BeforeActivation){
	b.Handle("GET","/something/{id:int64}","MyCustomerHandler",MyMiddleware)
}

func (m *MyController) Get() string{
	return  "Hey"
}

func (m *MyController) MyCustomerHandler(id int64) string{
	return "MyCustomHandler says Hey："
}


func MyMiddleware(ctx iris.Context){
	ctx.Next()
}