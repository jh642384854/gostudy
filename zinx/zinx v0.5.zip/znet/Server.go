package znet

import (
	"fmt"
	"github.com/kataras/iris/core/errors"
	"net"
	"zinx/utils"
	"zinx/ziface"
)

//iServer的接口实现，定义一个Server的服务器模块
type Server struct {
	//定义服务的一些基本属性
	Name string           //服务器的名称
	IPVersion string      //服务器绑定的IP版本+
	IPAddress string      //服务器绑定的IP地址
	Port int              //服务器监听的端口
	Router ziface.IRouter //添加router成员
}

//定义一个实现src/zinx/ziface/iconnection.go中的HandleFunc方法
func CallBackToClient(conn *net.TCPConn,buf []byte,contlen int) error {
	if _,err := conn.Write(buf[:contlen]); err != nil{
		return  errors.New("读取客户端传递的数据出错")
	}
	return nil
}

//启动服务器
func (this *Server) Start()  {
	fmt.Printf("zinx server start success,severname :%s,port:%d",utils.GloabConfigObj.ServerName,utils.GloabConfigObj.Port)
	go func() {
		//1.获取一个TCP的addr
		tcpAddres,err := net.ResolveTCPAddr(this.IPVersion,fmt.Sprintf("%s:%d",this.IPAddress,this.Port))
		if err != nil{
			fmt.Println("服务器连接失败")
			return
		}
		//2.监听服务器的地址
		tcpListen,err := net.ListenTCP(this.IPVersion,tcpAddres)
		if err != nil{
			fmt.Println("服务器监听失败")
			return
		}
		fmt.Println("start zinx server succ")
		//3.阻塞的等待客户端连接，处理客户端链接业务(读写)
		var connid uint32 = 0
		for {
			tcpConn,err := tcpListen.AcceptTCP()
			if err != nil{
				fmt.Println("接收客户端请求失败")
				continue
			}
			//将处理新连接的业务方法和tcpConn进行绑定，得到我们的链接模块
			dealConn := NewConnection(tcpConn,connid,this.Router)
			connid ++
			//启动当前的链接业务
			go dealConn.Start()
		}
	}()
}

//停止服务器
func (this *Server) Stop()  {

}

//运行服务器
func (this *Server) Run()  {
	//启动服务器功能
	this.Start()

	//阻塞状态
	select {

	}
}

func (this *Server) AddRouter(router ziface.IRouter){
	this.Router = router
}

//初始化Server模块的方法
/**
	注意这里的返回值是ziface.IServer这个接口对象。为什么是这个接口对象呢？
	因为我们还可以依据这个接口来实现很多别的服务，比如这里我们实现的是基于TCP协议的。
	我们当然还可以基于ziface.IServer这个接口对象来实现一个UDP协议的服务。
 */
func NewServer(name string) ziface.IServer  {
	s := &Server{
		Name:utils.GloabConfigObj.ServerName,
		IPVersion:"tcp4",
		IPAddress:utils.GloabConfigObj.Host,
		Port:utils.GloabConfigObj.Port,
		Router:nil,
	}
	return s
}