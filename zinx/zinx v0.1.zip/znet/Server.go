package znet

import (
	"fmt"
	"net"
	"zinx/ziface"
)

//iServer的接口实现，定义一个Server的服务器模块
type Server struct {
	//定义服务的一些基本属性
	Name string         //服务器的名称
	IPVersion string    //服务器绑定的IP版本
	IPAddress string    //服务器绑定的IP地址
	Port int            //服务器监听的端口
}
//启动服务器
func (this *Server) Start()  {
	go func() {
		//1.获取一个TCP的addr
		tcpAddres,err := net.ResolveTCPAddr(this.IPVersion,fmt.Sprintf("%s:%d",this.IPAddress,this.Port))
		if err != nil{
			fmt.Println("服务器连接失败")
			return
		}
		//2.监听服务器的地址
		tcpListen,err := net.ListenTCP(this.IPVersion,tcpAddres)
		if err != nil{
			fmt.Println("服务器监听失败")
			return
		}
		fmt.Println("start zinx server succ")
		//3.阻塞的等待客户端连接，处理客户端链接业务(读写)
		for {
			tcpConn,err := tcpListen.AcceptTCP()
			if err != nil{
				fmt.Println("接收客户端请求失败")
				continue
			}
			//已经与客户端建立了连接后，对客户端的基本操作
			go func() {
				for  {
					buf := make([]byte,512)
					contentLength ,err := tcpConn.Read(buf)
					if err != nil{
						fmt.Println("接收客户端请求失败")
						continue
					}
					fmt.Printf("接收客户端发送的信息：%s,长度:%d \n",buf,contentLength)
					//将消息回传给服务器端
					if _,err := tcpConn.Write(buf[:contentLength]); err != nil{
						fmt.Println("向服务器发生消息失败")
						continue
					}

				}
			}()
		}
	}()
}

//停止服务器
func (this *Server) Stop()  {

}

//运行服务器
func (this *Server) Run()  {
	//启动服务器功能
	this.Start()

	//阻塞状态
	select {

	}
}

//初始化Server模块的方法
/**
	注意这里的返回值是ziface.IServer这个接口对象。为什么是这个接口对象呢？
	因为我们还可以依据这个接口来实现很多别的服务，比如这里我们实现的是基于TCP协议的。
	我们当然还可以基于ziface.IServer这个接口对象来实现一个UDP协议的服务。
 */
func NewServer(name string) ziface.IServer  {
	s := &Server{
		Name:name,
		IPVersion:"tcp4",
		IPAddress:"0.0.0.0",
		Port:8999,
	}
	return s
}