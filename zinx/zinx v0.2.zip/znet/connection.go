package znet

import (
	"fmt"
	"net"
	"zinx/ziface"
)

type Connection struct {
	//当前链接的socket TCP套接字
	Conn *net.TCPConn

	//链接ID
	ConnID uint32

	//当前链接的状态
	IsClosed bool

	//当前链接所绑定的处理业务方法API
	handAPI ziface.HandleFunc

	//告知当前链接已经退出或停止  channel
	ExitChan chan bool
}


//初始化Connection方法

func NewConnection(conn *net.TCPConn,connID uint32,callback_api ziface.HandleFunc) *Connection {
	c := &Connection{
		Conn:conn,
		ConnID:connID,
		handAPI:callback_api,
		IsClosed:false,
		ExitChan:make(chan bool, 1),
	}
	return  c
}

//从服务端读取数据的方法
func (this *Connection)  StartReader()  {
	fmt.Println("Reader Goroutine is Running......")

	defer this.Stop()
	defer fmt.Println("Conn：",this.ConnID," Reader is exit,remote add is ",this.GetRemoteAddr().String())

	//循环读取(阻塞)
	for  {
		buf := make([]byte,512)
		conlength,err := this.Conn.Read(buf)
		if err != nil{
			fmt.Println("recv data err",err)
			continue  //如果本次读取数据出错，则跳过，等待下一次客户端传递数据继续读取
		}
		//获取客户端传递的数据后，该如何处理呢？这里就要调用我们定义的自定义handapi来处理了

		if err := this.handAPI(this.Conn,buf,conlength); err != nil{
			fmt.Println("ConnID:",this.ConnID," handler is error")
			break //如果调用用户自定义的handle出错，就退出请求
		}

	}
}

//实现zinx/ziface的IConnection这个方法
//1.启动链接，让当前链接准备开始工作
func (this *Connection) Start(){
	fmt.Println("Conn Start ... ConnID = ",this.ConnID)
	go this.StartReader()
}

//2.停止链接，结束当前的链接工作
func (this *Connection) Stop(){
	fmt.Println("conn stop .. ConnID:",this.ConnID)

	//判断是否已经关闭
	if this.IsClosed {
		return
	}
	this.IsClosed = true

	//关闭socket链接
	this.Conn.Close()
	//关闭管道
	close(this.ExitChan)
}

//3.获取当前链接绑定的socket conn
func (this *Connection) GetTCPConnection() *net.TCPConn{
	return this.Conn
}

//4.获取当前链接模块的链接ID
func (this *Connection) GetConnectionID() uint32{
	return this.ConnID
}

//5.获取远程客户端的TCP状态信息，比如IP和端口等等
func (this *Connection) GetRemoteAddr() net.Addr{
	return this.Conn.RemoteAddr()
}

//6.发送数据，将数据发送给远程的客户端
func (this *Connection) Send(data []byte) error{
	return nil
}